---
name: devtools
description: 扩展 LytJS DevTools 功能，包含轻量级内嵌面板和浏览器扩展后端开发
---
# devtools

## 描述

扩展 LytJS DevTools 功能，支持轻量级内嵌面板和浏览器扩展后端两种开发模式。

## 何时使用

- 需要扩展 DevTools 功能时
- 开发新的调试面板或功能
- 增强开发者调试体验

## 架构说明

### 两种 DevTools 版本

| 位置 | 说明 |
|------|------|
| `ecosystem/devtools` | 轻量级内嵌面板，面向开发者快速调试 |
| `tools/devtools` | 浏览器扩展后端，提供高级调试能力 |

## 开发指南

### ecosystem 版本（轻量级）

- 适用场景：快速调试功能、轻量级面板
- 开发方式：直接修改 `src/devtools.ts` 中的面板渲染逻辑
- 特点：零依赖、随应用加载

```typescript
// ecosystem/devtools/src/devtools.ts
export function renderDevTools(app: any) {
  // 面板渲染逻辑
  const panel = createPanel();

  panel.addTab({
    name: 'signals',
    title: '响应式状态',
    render: () => renderSignalsPanel()
  });

  panel.addTab({
    name: 'components',
    title: '组件树',
    render: () => renderComponentsPanel()
  });

  return panel;
}
```

### tools 版本（浏览器扩展）

- 适用场景：高级调试、浏览器扩展能力
- 开发方式：在对应子模块中添加功能
- 子模块结构：
  - `signals/` - 信号/响应式状态监控
  - `events/` - 事件追踪
  - `snapshots/` - 状态快照
  - `panel/*/` - 各面板实现

```typescript
// tools/devtools/src/signals/index.ts
import { createSignalTracker } from './tracker';

export function initSignalsModule() {
  const tracker = createSignalTracker();

  return {
    getSignals: () => tracker.getAll(),
    subscribe: (callback) => tracker.onChange(callback)
  };
}
```

## 新增功能流程

1. 在对应子模块中添加功能实现
2. 在 `src/index.ts` 中导出新功能
3. 编写测试文件确保功能正常
4. 更新面板 UI 以展示新功能

## 测试

确保新增功能有对应的测试覆盖：

```typescript
import { describe, it, expect } from 'vitest';
import { initSignalsModule } from '../src/signals';

describe('signals module', () => {
  it('应正确追踪信号变化', () => {
    const module = initSignalsModule();
    expect(module.getSignals()).toBeDefined();
  });
});
```
