# LytJS 代码风格统一指南

## 描述

为 LytJS 项目提供统一的代码风格规范，确保代码库的一致性和可读性。

## 何时使用

- 需要统一代码风格时
- 编写新代码时
- 审查代码风格时

## 格式检查和修复

```bash
# 运行代码格式检查
pnpm lint:check

# 自动修复格式问题
pnpm lint:fix
```

## 命名规范

### 变量和函数

```typescript
// ✅ 推荐：使用 camelCase
const userName = '张三';
function calculateTotal() {}

// ❌ 避免
const UserName = '张三';
function CalculateTotal() {}
```

### 常量

```typescript
// ✅ 推荐：使用 UPPER_SNAKE_CASE
const MAX_COUNT = 100;
const API_BASE_URL = 'https://api.example.com';
```

### 类型和接口

```typescript
// ✅ 推荐：使用 PascalCase
interface UserOptions {}
type ResponseData = {};
```

### 文件命名

```typescript
// ✅ 推荐：使用 kebab-case
// reactivity.ts
// vdom-pool.ts

// ❌ 避免
// Reactivity.ts
// vdomPool.ts
```

## 代码格式化

### 缩进

```typescript
// ✅ 推荐：使用 2 个空格
function add(a, b) {
  return a + b;
}

// ❌ 避免
function add(a, b) {
    return a + b;
}
```

### 分号

```typescript
// ✅ 推荐：使用分号
const count = 0;

// ❌ 避免
const count = 0
```

### 引号

```typescript
// ✅ 推荐：使用单引号
const name = '张三';

// 字符串包含单引号时使用双引号
const message = "I'm fine";

// 模板字符串使用反引号
const greeting = `Hello, ${name}`;
```

### 对象和数组

```typescript
// ✅ 推荐
const obj = { name: '张三', age: 20 };

// 多行时最后一个属性带逗号
const obj = {
  name: '张三',
  age: 20,
};

const arr = [1, 2, 3];
```

## 语法最佳实践

### 使用 const 而不是 let

```typescript
// ✅ 推荐
const count = 0;

// ❌ 避免（不会修改的变量）
let count = 0;
```

### 使用箭头函数

```typescript
// ✅ 推荐
const add = (a, b) => a + b;

// 多行时带花括号
const process = (data) => {
  const result = transform(data);
  return result;
};
```

### 使用模板字符串

```typescript
// ✅ 推荐
const greeting = `Hello, ${name}`;

// ❌ 避免
const greeting = 'Hello, ' + name;
```

### 使用解构赋值

```typescript
// ✅ 推荐
const { name, age } = user;
const [first, second] = items;

// ❌ 避免
const name = user.name;
const age = user.age;
```

## 函数规范

### 函数长度

```typescript
// ✅ 推荐：函数不超过 50 行
function processOrder(order) {
  validateOrder(order);
  const total = calculateTotal(order);
  return applyDiscount(total, order);
}

// 每个小函数只做一件事
function validateOrder(order) { /* ... */ }
function calculateTotal(order) { /* ... */ }
function applyDiscount(total, order) { /* ... */ }
```

### 参数数量

```typescript
// ✅ 推荐：参数不超过 3 个
function createUser(name, age, email) { /* ... */ }

// 超过 3 个时使用对象
function createUser(options) {
  const { name, age, email, address, phone } = options;
}
```

## 注释规范

### JSDoc 注释

```typescript
/**
 * 创建响应式引用
 * @param value - 初始值
 * @returns 响应式引用对象
 */
function ref(value) { /* ... */ }
```

### 行内注释

```typescript
// ✅ 推荐：注释解释为什么，而不是做什么
// 需要排序是因为后续依赖有序数组
const sorted = [...items].sort();

// ❌ 避免
// 排序数组
const sorted = [...items].sort();
```

## 代码风格检查清单

- [ ] 运行了 pnpm lint:check
- [ ] 命名符合规范
- [ ] 代码格式化正确
- [ ] 使用了 const 而不是 let（合适时）
- [ ] 函数简短精炼
- [ ] 注释清晰有用
- [ ] 没有冗余代码

## 详细文档

- [DEVELOPMENT_GUIDELINES.md](file:///f:/trae/lytjs/docs/development/DEVELOPMENT_GUIDELINES.md) - 完整开发规范
- [lytjs-chinese-docs-guide](file:///f:/trae/lytjs/.trae/skills/lytjs-chinese-docs-guide/SKILL.md) - 中文文档规范
- [lytjs-code-review](file:///f:/trae/lytjs/.trae/skills/lytjs-code-review/SKILL.md) - 代码审查指南
