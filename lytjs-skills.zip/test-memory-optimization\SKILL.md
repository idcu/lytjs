---
name: test-memory-optimization
description: 解决测试中的 heap out of memory 内存溢出问题，优化 Vitest 配置
---
# test-memory-optimization

## 描述

解决 Vitest 测试中的内存溢出问题（heap out of memory），提供配置优化方案。

## 何时使用

- 测试运行时出现 `heap out of memory` 错误
- 内存密集型测试导致系统资源耗尽
- 需要优化测试执行效率时

## 快速修复

修改 `vitest.config.ts`：

```typescript
test: {
  exclude: [
    '**/node_modules/**',
    '**/dist/**',
    '**/tests/edge-cases.test.ts'  // 排除内存密集测试
  ],
  // 可选配置
  testTimeout: 30000,
  hookTimeout: 30000,
  poolOptions: {
    threads: { singleThread: true }  // 单线程运行
  }
}
```

## 单独运行被排除的测试

当需要运行被排除的内存密集测试时，使用以下命令：

```bash
cd packages/reactivity
NODE_OPTIONS="--max-old-space-size=8192" pnpm test tests/edge-cases.test.ts --run
```

## 相关文件

- [packages/reactivity/vitest.config.ts](file:///f:/trae/lytjs/packages/reactivity/vitest.config.ts)
