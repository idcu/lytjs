# LytJS 测试开发指南

## 描述

为 LytJS 项目提供测试开发的最佳实践，包括测试模板、测试环境配置、常见问题解决等。

## 何时使用

- 需要为新功能添加测试时
- 修复测试失败时
- 了解测试最佳实践时
- 配置测试环境时

## 测试模板

### 基础测试模板

```typescript
// packages/{module}/tests/{feature}.test.ts
import { describe, it, expect, vi, beforeEach } from 'vitest';
import { functionName } from '../src/{source-file}';

describe('{feature}', () => {
  beforeEach(() => {
    // 初始化
  });

  it('应正确处理基本场景', () => {
    // Arrange
    const input = ...;
    // Act
    const result = functionName(input);
    // Assert
    expect(result).toBe(expected);
  });

  it('应处理边界情况', () => {
    // 边界条件测试
  });

  it('应正确处理错误输入', () => {
    // 错误处理测试
  });
});
```

## 测试环境

### vdom 包测试

vdom 包测试需要使用 jsdom 环境，运行测试时使用:

```bash
pnpm test --config packages/vdom/vitest.config.ts
```

### 路径别名问题

如果测试中遇到无法解析 `@lytjs/reactivity/scope` 等子路径导出的问题:

**解决方案**:
1. 先运行 `pnpm build` 构建依赖包
2. 在测试中使用 require() 导入构建后的文件

```typescript
const pluginModule = require('../dist/index.cjs');
```

## 测试覆盖率要求

| 模块 | 最低覆盖率 |
|------|-----------|
| reactivity | ≥ 90% |
| vdom | ≥ 85% |
| compiler | ≥ 80% |
| core | ≥ 80% |

## UI 组件测试注意事项

1. 先查看组件实际实现，确认 props 名称和默认值，避免假设
2. 对于函数返回的默认值（如 Array、Object），只需验证函数存在，不要比较返回值
3. 对于可能为 undefined 的默认值，使用 `toBeUndefined()` 而非 `toBe('')` 或 `toBe(0)`
4. 组件测试应覆盖: 基本渲染、props 定义、默认值、导出正确性等基本检查

## 测试常见问题

### document is not defined

**原因**: 测试需要浏览器环境

**解决方案**: 使用 jsdom 环境，或为 vdom 包使用专门的配置文件

### Cannot find module

**原因**: 依赖包未构建

**解决方案**: 先运行 `pnpm build` 构建依赖包

### process is not defined

**原因**: Vitest 与 Node.js 版本兼容性问题

**解决方案**: 检查 Node.js 版本（≥ 18.0.0），或查看具体错误信息

## 测试运行命令

```bash
# 运行所有测试
pnpm test

# 运行单个包的测试
cd packages/{module} && pnpm test

# 运行特定测试文件
pnpm test {test-file-path}

# 监听模式运行测试
pnpm test --watch
```

## 详细文档

完整的测试指南请参考: `docs/development/DEVELOPMENT_SKILLS.md` 中的 Skill 1
