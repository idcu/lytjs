# LytJS 文档生成指南

## 描述

为 LytJS 项目提供文档编写和 API 文档生成的最佳实践，确保文档质量和一致性。

## 何时使用

- 需要编写 API 文档时
- 需要更新 README 时
- 需要生成 API 参考文档时

## JSDoc 注释规范

### 公共 API 必须有完整 JSDoc

```typescript
/**
 * 创建响应式引用（Ref）
 *
 * @description
 * 将普通值包装为响应式引用对象，可通过 .value 属性访问和修改值。
 * 当值改变时，会自动触发相关的响应式更新。
 *
 * @param value - 初始值
 * @returns 响应式引用对象
 *
 * @example
 * ```typescript
 * const count = ref(0);
 * console.log(count.value); // 0
 *
 * // 修改值
 * count.value++;
 * console.log(count.value); // 1
 *
 * // 响应式更新
 * effect(() => {
 *   console.log('count changed:', count.value);
 * });
 * ```
 *
 * @template T - 值的类型
 * @see reactive - 创建响应式对象
 * @see computed - 创建计算属性
 * @since 6.0.0
 */
export function ref<T>(value: T): Ref<T> {
  // 实现
}
```

### 必填标签

- `@description` - 详细描述
- `@param` - 参数说明
- `@returns` - 返回值说明
- `@example` - 使用示例
- `@see` - 相关 API 链接
- `@since` - 版本信息

### 可选标签

- `@template` - 泛型说明
- `@throws` - 异常说明
- `@deprecated` - 弃用标记

## README 文档结构

### 标准 README 结构

```markdown
# @lytjs/包名

简短的包功能描述

## 功能特性

- 功能 1
- 功能 2
- 功能 3

## 快速开始

### 安装

```bash
pnpm add @lytjs/包名
```

### 基本使用

```typescript
import { xxx } from '@lytjs/包名';

// 使用示例
```

## API 参考

### xxx

函数说明

**参数：**
- `param1` - 参数说明

**返回值：**
返回值说明

**示例：**
```typescript
// 示例代码
```

## 详细文档

查看完整文档：[链接]

## 许可证

MIT
```

## 不同类型的文档

### 1. API 参考文档

位置：`docs/api/包名.md`

内容：
- 完整的 API 列表
- 每个 API 的详细说明
- 使用示例
- 类型定义

### 2. 指南文档

位置：`docs/guide/xxx.md`

内容：
- 功能介绍
- 使用教程
- 最佳实践
- 常见问题

### 3. 架构文档

位置：`docs/architecture/xxx.md`

内容：
- 架构设计
- 实现原理
- 技术选型

## 文档编写最佳实践

### 使用中文为主

```markdown
✅ 推荐：
# 响应式系统

响应式系统是 LytJS 的核心...

❌ 避免：
# Reactivity System

The reactivity system is core of LytJS...
```

### 代码示例完整可运行

```typescript
// ✅ 推荐：完整的示例
import { ref, effect } from '@lytjs/reactivity';

const count = ref(0);
effect(() => {
  console.log(count.value);
});
count.value++; // 输出: 1

// ❌ 避免：不完整的示例
const count = ref(0);
count.value++;
```

### 使用表格组织复杂信息

```markdown
| 方法 | 说明 | 参数 |
|------|------|------|
| ref() | 创建响应式引用 | value - 初始值 |
| reactive() | 创建响应式对象 | target - 目标对象 |
```

### 使用提示框

```markdown
> [!NOTE]
> 注意事项...

> [!WARNING]
> 警告信息...

> [!TIP]
> 有用的提示...
```

## 文档检查清单

在提交文档前，检查以下项目：

- [ ] 所有公共 API 都有 JSDoc 注释
- [ ] JSDoc 包含必要的标签
- [ ] 有使用示例
- [ ] 文档使用中文
- [ ] 代码示例正确可运行
- [ ] 链接都有效
- [ ] 格式清晰易读
- [ ] 没有拼写错误

## 文档更新流程

### 1. 更新代码注释

```typescript
/**
 * 更新后的函数说明
 * @param param - 更新后的参数说明
 */
```

### 2. 更新相关文档

- README.md
- API 参考文档
- 指南文档

### 3. 检查和验证

```bash
# 确保文档格式正确
# 检查链接是否有效
```

### 4. 提交更新

```bash
git add docs/xxx.md
git commit -m "docs: 更新 xxx 文档"
```

## 详细文档

- [CHINESE_DOCS_GUIDE.md](file:///f:/trae/lytjs/docs/development/CHINESE_DOCS_GUIDE.md) - 中文文档规范
- [DEVELOPMENT_GUIDELINES.md](file:///f:/trae/lytjs/docs/development/DEVELOPMENT_GUIDELINES.md) - 开发规范
