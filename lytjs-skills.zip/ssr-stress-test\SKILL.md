---
name: ssr-stress-test
description: 执行 SSR 性能压力测试，支持 10000+ 并发请求测试，用于验证性能指标
---
# ssr-stress-test

## 描述

执行服务端渲染（SSR）的性能压力测试，支持多种并发级别，从基础测试到极限压力测试。

## 何时使用

- 验证 SSR 性能指标
- 需要进行 10000+ 并发请求测试时
- 性能基准测试和对比

## 快速开始

```bash
cd packages/ecosystem/packages/ssr
npx tsx tests/stress-test.ts
```

## 测试场景

1. **基础测试**：100 请求 / 10 并发
2. **中等并发**：500 请求 / 50 并发
3. **高并发**：1000 请求 / 100 并发
4. **稳定性测试**：持续 3000ms
5. **极限测试**：10000+ / 15000 请求

## 性能参考（2026-05-16）

| 场景 | 请求数 | 并发 | 成功率 | QPS |
|------|--------|------|--------|-----|
| 极限测试 | 15000 | 1000 | 100% | 74,336 |
| 极限测试 | 10000 | 500 | 100% | 33,874 |

## 报告保存位置

`benchmarks/results/ssr-stress-test-YYYY-MM-DD.md`

## 相关文件

- [packages/ecosystem/packages/ssr/tests/stress-test.ts](file:///f:/trae/lytjs/packages/ecosystem/packages/ssr/tests/stress-test.ts)
