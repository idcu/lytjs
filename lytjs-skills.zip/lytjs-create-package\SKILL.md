# LytJS 创建新包指南

## 描述

为 LytJS 项目提供创建新包的完整指南，包括创建生态系统包、官方插件等。

## 何时使用

- 需要创建新的生态系统包时
- 需要创建新的官方插件时
- 需要迁移现有包时
- 需要了解包结构时

## 创建新生态系统包

### 步骤

1. 创建目录结构：`src/`, `tests/`, `package.json`, `tsconfig.json`, `tsup.config.ts`
2. `package.json` 中声明 workspace 依赖
3. `tsup.config.ts` 启用 `dts: true`
4. 在 `src/index.ts` 中统一导出
5. 编写测试文件
6. 在根 `vitest.config.ts` 中添加别名（如需）
7. 在根 `package.json` 中添加构建脚本
8. 更新 `pnpm-workspace.yaml`

### 包模板

```json
{
  "name": "@lytjs/{package-name}",
  "version": "6.0.0",
  "type": "module",
  "main": "./dist/index.mjs",
  "types": "./dist/index.d.ts",
  "exports": {
    ".": { "import": "./dist/index.mjs", "types": "./dist/index.d.ts" }
  },
  "scripts": {
    "build": "tsup",
    "test": "vitest run",
    "dev": "tsup --watch"
  }
}
```

## 创建新官方插件

### 步骤

1. 使用 `docs/development/PLUGIN_DEVELOPMENT.md` 中提供的模板创建插件
2. 确保包名格式为 `@lytjs/plugin-{name}`
3. 使用 `definePlugin()` API 实现插件功能
4. 添加配置验证 schema
5. 基于 `common-is`、`common-constants` 等工具实现，零第三方依赖
6. 编写完整测试（使用 `require()` 导入构建后文件）
7. 在 `packages/plugins/packages/index.ts` 中统一导出
8. 更新根 `package.json` 的 `build:plugins` 脚本
9. 更新插件文档 `README.md`

### 测试技巧

```typescript
const pluginModule = require('../dist/index.cjs');

describe('@lytjs/plugin-{name}', () => {
  it('应导出默认插件', () => {
    expect(pluginModule.default).toBeDefined();
  });

  it('应导出主要工具函数', () => {
    expect(pluginModule.someFunction).toBeDefined();
  });
});
```

## 包迁移与重构

### 适用场景

将包从一个目录移动到另一个目录（如从 ecosystem 迁移到 plugins）

### 步骤

1. 复制目标包的完整目录结构
2. 重命名包名（如从 `@lytjs/i18n` 到 `@lytjs/plugin-i18n`）
3. 更新 `package.json` 中的 name、repository、keywords 等字段
4. 统一构建脚本和测试脚本风格
5. 更新所有引用该包的地方（导入语句、文档等）
6. 在根 `package.json` 中更新构建脚本
7. 删除旧的包目录
8. 运行构建和测试验证
9. 更新 `pnpm-workspace.yaml`

### 验证检查

- [ ] 构建成功，无类型错误
- [ ] 所有测试通过
- [ ] 零依赖规范检查通过
- [ ] 文档已更新
- [ ] 无残留的旧包引用

## 常用命令

```bash
# 构建新包
cd packages/{package-name} && pnpm build

# 测试新包
cd packages/{package-name} && pnpm test

# 检查类型
pnpm type-check

# 零依赖检查
pnpm run check-zero-deps
```

## 详细文档

完整的创建新包指南请参考: `docs/development/DEVELOPMENT_SKILLS.md` 中的 Skill 2、5、6
