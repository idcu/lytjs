---
name: create-plugin
description: 创建官方插件，使用 definePlugin() API，包含配置验证和测试模板
---
# create-plugin

## 描述

在 `packages/plugins/packages/` 目录下创建 LytJS 官方插件，使用标准化的插件开发流程。

## 何时使用

- 需要开发 LytJS 官方插件时
- 扩展框架核心功能

## 开发步骤

### 1. 遵循开发指南

使用 [PLUGIN_DEVELOPMENT.md](file:///f:/trae/lytjs/docs/development/PLUGIN_DEVELOPMENT.md) 中的模板和最佳实践

### 2. 包命名规范

包名格式：`@lytjs/plugin-{name}`

例如：
- `@lytjs/plugin-animation`
- `@lytjs/plugin-form`

### 3. 使用 definePlugin() API

```typescript
import { definePlugin } from '@lytjs/core';

export default definePlugin({
  name: '@lytjs/plugin-{name}',
  setup() {
    // 插件逻辑
  },
  configSchema: {
    // 配置验证 schema
  }
});
```

### 4. 配置验证

添加配置验证 schema，确保用户配置的正确性：

```typescript
configSchema: {
  enable: { type: 'boolean', default: true },
  options: { type: 'object' }
}
```

### 5. 零依赖原则

- 基于 `@lytjs/common-is`、`@lytjs/common-constants` 等零第三方依赖工具
- 避免引入外部运行时依赖

### 6. 编写测试

使用 `require()` 导入构建后文件进行测试：

```typescript
const pluginModule = require('../dist/index.cjs');

describe('@lytjs/plugin-{name}', () => {
  it('应导出默认插件', () => {
    expect(pluginModule.default).toBeDefined();
  });

  it('应导出主要工具函数', () => {
    expect(pluginModule.someFunction).toBeDefined();
  });
});
```

### 7. 统一导出

在 `packages/plugins/packages/index.ts` 中添加导出：

```typescript
export { default as pluginName } from './plugin-name/dist/index.cjs';
```

### 8. 更新构建脚本

更新根 `package.json` 的 `build:plugins` 脚本

## 验证清单

- [ ] 使用 PLUGIN_DEVELOPMENT.md 模板
- [ ] 包名格式正确
- [ ] 使用 definePlugin() API
- [ ] 添加配置验证 schema
- [ ] 零第三方依赖
- [ ] 测试通过
- [ ] 统一导出已添加
- [ ] 构建脚本已更新
