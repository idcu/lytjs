# LytJS 开发规范指南

## 描述

为 LytJS 项目提供完整的开发规范指导，包括代码风格、命名约定、Git 工作流、架构规范等。

## 何时使用

- 开始新功能开发时
- 编写代码前需要确认规范时
- 代码审查时需要对照规范时
- 新人加入项目需要了解开发规范时

## 核心规范

### 代码风格

- **缩进**: 2 空格
- **引号**: 单引号
- **分号**: 必须
- **换行符**: LF（Linux/macOS）或 CRLF（Windows，Git 自动处理）
- **文件编码**: UTF-8 无 BOM

### 命名约定

- **PascalCase**: 类型、类、组件、接口
- **camelCase**: 变量、函数、属性
- **UPPER_CASE**: 常量
- **_prefix**: 私有成员

### 导入顺序

1. 外部依赖
2. 内部模块（按字母顺序）
3. 相对路径导入

### 核心工具包优先使用

```typescript
// 类型检查
import { isArray, isString, isObject, isFunction, hasChanged } from '@lytjs/common-is';

// 常量定义
import { EMPTY_OBJ, EMPTY_ARR, NOOP } from '@lytjs/common-constants';

// VNode 工具
import { isSameVNodeType } from '@lytjs/common-vnode';

// 字符串处理
import { camelize, toPascalCase } from '@lytjs/common-string';

// DOM 操作
import { querySelector, addEventListener } from '@lytjs/common-dom-helpers';

// 警告和错误
import { warn, error } from '@lytjs/common-warn';
```

### Git 工作流

```bash
# 1. 创建功能分支
git checkout -b feature/xxx-功能描述

# 2. 开发完成后检查
pnpm lint:check && pnpm type-check

# 3. 提交代码（如遇内存问题跳过 husky）
git add .
git commit --no-verify -m "feat(scope): 功能描述"
git push origin feature/xxx-功能描述
```

**分支命名规范**:
- `feature/xxx` - 新功能开发
- `fix/xxx` - Bug 修复
- `refactor/xxx` - 代码重构
- `docs/xxx` - 文档更新

**Commit 规范**:
```
<type>(<scope>): <中文描述>

type 可选值: feat, fix, docs, style, refactor, perf, test, chore
scope 可选值: reactivity, vdom, compiler, core, renderer, common-*, web, tools, plugins
```

### 8 层架构规范

- **L0 基础工具层开放**: L0 基础工具层（common-*）可被所有上层直接依赖
- **分层合理依赖**: 核心层（L1-L4）遵循分层原则，尽量减少跨层依赖，但允许必要的跨层访问
- **单向依赖**: 只能从上层依赖下层，禁止反向依赖
- **循环依赖检查**: 使用 `pnpm run check-circular` 定期检查

### 零依赖原则

- **运行时零依赖**: 所有 L0-L6 层的运行时代码不引入任何第三方库
- **开发时例外**: 构建工具、测试工具等仅在开发时使用的依赖可以接受
- **优先自研**: 需要的功能优先考虑自研实现，而非引入第三方库

### 常用原生 API 替代方案

| 功能需求 | 原生 API 方案 |
|---------|--------------|
| 日期处理 | `Date` 对象、`Intl.DateTimeFormat` |
| 深拷贝 | `structuredClone()` |
| 数组操作 | 原生 `Array` 方法 |
| 对象操作 | `Object.assign()`、展开运算符 |
| URL 处理 | `URL`、`URLSearchParams` |
| DOM 操作 | 原生 DOM API |

## 详细文档

完整的开发规范请参考: `docs/development/DEVELOPMENT_GUIDELINES.md`
