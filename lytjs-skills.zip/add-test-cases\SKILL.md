---
name: add-test-cases
description: 为已有模块补充测试用例，包含测试模板和 UI 组件测试注意事项
---
# add-test-cases

## 描述

为 LytJS 项目中的已有模块补充测试覆盖，包含标准的测试模板和最佳实践。

## 何时使用

- 需要为现有代码添加测试覆盖时
- 新增功能后需要编写测试用例
- 提升代码测试覆盖率

## 测试模板

```typescript
// packages/{module}/tests/{feature}.test.ts
import { describe, it, expect, vi, beforeEach } from 'vitest';
import { functionName } from '../src/{source-file}';

describe('{feature}', () => {
  beforeEach(() => {
    // 初始化
  });

  it('应正确处理基本场景', () => {
    // Arrange
    const input = ...;
    // Act
    const result = functionName(input);
    // Assert
    expect(result).toBe(expected);
  });

  it('应处理边界情况', () => {
    // 边界条件测试
  });

  it('应正确处理错误输入', () => {
    // 错误处理测试
  });
});
```

## UI 组件测试注意事项

1. **查看组件实际实现**：先查看组件源码，确认 props 名称和默认值，避免假设
2. **默认值验证**：对于函数返回的默认值（如 Array、Object），只需验证函数存在，不要比较返回值
3. **undefined 检查**：对于可能为 undefined 的默认值，使用 `toBeUndefined()` 而非 `toBe('')` 或 `toBe(0)`
4. **覆盖范围**：组件测试应覆盖：基本渲染、props 定义、默认值、导出正确性等基本检查

## 特殊环境要求

- **vdom 包测试**：需要使用 jsdom 环境，在 `packages/vdom/vitest.config.ts` 中配置
- **mock 外部依赖**：使用 `vi.mock()`
- **创建 spy**：使用 `vi.fn()`
- **路径别名问题**：可直接导入构建后的 CJS 文件绕过

## 命令

```bash
pnpm --filter {package} test
```
