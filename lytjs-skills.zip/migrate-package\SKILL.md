---
name: migrate-package
description: 包的迁移和重构，将包从一个目录移动到另一个目录，包含完整的迁移流程
---
# migrate-package

## 描述

将 LytJS 包从一个目录移动或重构到另一个目录，包含完整的迁移流程和验证清单。

## 何时使用

- 包的结构需要调整
- 需要将包从 ecosystem 迁移到 plugins
- 包的重命名和重组

## 迁移步骤

### 1. 备份和复制

复制目标包的完整目录结构到新位置

### 2. 重命名包

更新 `package.json` 中的字段：

```json
{
  "name": "@lytjs/plugin-{new-name}",
  "repository": {
    "type": "git",
    "url": "...",
    "directory": "packages/plugins/packages/{new-name}"
  },
  "keywords": ["lytjs", "plugin", ...]
}
```

### 3. 统一脚本风格

确保构建脚本和测试脚本风格与项目一致：

```json
{
  "scripts": {
    "build": "tsup",
    "test": "vitest run",
    "dev": "tsup --watch"
  }
}
```

### 4. 更新引用

更新所有引用该包的地方：
- 导入语句
- 文档中的引用
- 配置文件中的别名

### 5. 更新构建脚本

在根 `package.json` 中更新构建脚本

### 6. 删除旧包

确认新包工作正常后，删除旧的包目录

### 7. 更新 workspace 配置

更新 `pnpm-workspace.yaml` 中的包路径

### 8. 验证

运行构建和测试确保迁移成功

## 验证清单

- [ ] 构建成功，无类型错误
- [ ] 所有测试通过
- [ ] 零依赖规范检查通过
- [ ] 文档已更新
- [ ] 无残留的旧包引用
- [ ] pnpm-workspace.yaml 已更新

## 相关文件

- [pnpm-workspace.yaml](file:///f:/trae/lytjs/pnpm-workspace.yaml)
- [根 package.json](file:///f:/trae/lytjs/package.json)
