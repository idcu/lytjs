---
name: create-tool-script
description: 创建工程化工具脚本，使用 Node.js 原生 API，遵循零第三方依赖原则
---
# create-tool-script

## 描述

在 `scripts/` 目录下创建项目级别的工具脚本，使用 Node.js 原生 API，遵循零第三方依赖原则。

## 何时使用

- 需要创建新的项目脚本工具时
- 需要维护或修改现有脚本时
- 需要了解项目工程化流程时
- 需要创建自动化检查或发布脚本时

## 现有脚本概览

**位置**：[scripts/](file:///f:/trae/lytjs/scripts/)

### 核心脚本列表

| 脚本 | 文件 | 描述 |
|------|------|------|
| 零依赖检查 | check-zero-deps.ts | 检查所有包是否遵循零依赖规范 |
| 循环依赖检查 | check-circular.ts | 检查包之间的循环依赖 |
| 依赖检查 | check-deps.ts | 检查项目依赖使用情况 |
| 版本同步 | sync-versions.ts | 同步所有包的版本号 |
| 发布准备 | prepare-publish.ts | 发布前准备工作 |
| API 文档生成 | gen-api-docs.ts | 生成 API 文档 |
| 内存检查 | memlab-check.ts | 内存泄漏检查 |
| 已发布检查 | check-published.mjs | 检查包是否已发布 |
| 发布脚本 | npm-publish.ts | 发布包到 npm |
| 工作区恢复 | restore-workspace.ts | 恢复 workspace 配置 |

### 测试脚本

| 脚本 | 描述 |
|------|------|
| build-all.sh | 构建所有包 |
| test-all.sh | 运行所有测试 |
| publish.sh | 完整发布流程 |

## 创建新脚本

### 基本步骤

1. 在 `scripts/` 目录下创建新脚本
2. 使用 Node.js 原生 API，零第三方依赖
3. 在 package.json 中添加对应脚本命令
4. 编写脚本的测试用例（可选）
5. 更新文档加入新命令

### 脚本模板

```typescript
/**
 * 脚本描述
 *
 * 详细说明脚本的功能和用途
 */

import { readFileSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';

// 配置常量
const CONFIG = {
  targetDir: 'packages/',
  outputFile: 'result.json',
};

// 主函数
function main() {
  console.log('开始执行脚本...');

  try {
    // 执行主要逻辑
    const result = processFiles();

    // 输出结果
    console.log('✅ 执行成功！');
    console.log('结果:', result);
  } catch (error) {
    console.error('❌ 执行失败:', error);
    process.exit(1);
  }
}

// 核心处理函数
function processFiles() {
  // 实现具体逻辑
  return { success: true };
}

main();
```

### package.json 配置

在根目录 `package.json` 中添加脚本命令：

```json
{
  "scripts": {
    "my-script": "tsx scripts/my-script.ts",
    "my-script:test": "vitest run scripts/tests/my-script.test.ts"
  }
}
```

## 零依赖检查脚本示例

### 功能说明

检查 LytJS 项目中所有包是否遵循运行时零第三方依赖原则，仅允许 devDependencies 中使用第三方依赖，dependencies 必须只包含 @lytjs/* 包。

### 完整实现

```typescript
import { readFileSync, readdirSync, statSync } from 'node:fs';
import { join, relative } from 'node:path';

interface PackageInfo {
  name: string;
  path: string;
  dependencies: Record<string, string>;
  devDependencies: Record<string, string>;
}

interface Violation {
  packageName: string;
  packagePath: string;
  violations: string[];
}

const INTERNAL_PREFIX = '@lytjs/';
const EXEMPT_PACKAGES = new Set([
  '@lytjs/test-utils',
]);

const SCAN_TARGETS = [
  'packages/common/packages',
  'packages/plugins/packages',
  'packages/ecosystem/packages',
];

function isInternalPackage(name: string): boolean {
  return name.startsWith(INTERNAL_PREFIX);
}

function parsePackageJson(dirPath: string): PackageInfo | null {
  try {
    const packageJsonPath = join(dirPath, 'package.json');
    const content = readFileSync(packageJsonPath, 'utf-8');
    const pkg = JSON.parse(content);

    return {
      name: pkg.name,
      path: dirPath,
      dependencies: pkg.dependencies || {},
      devDependencies: pkg.devDependencies || {},
    };
  } catch {
    return null;
  }
}

function scanDirectory(dirPath: string): PackageInfo[] {
  const packages: PackageInfo[] = [];

  try {
    const entries = readdirSync(dirPath);

    for (const entry of entries) {
      const fullPath = join(dirPath, entry);

      try {
        const stat = statSync(fullPath);

        if (stat.isDirectory()) {
          const pkg = parsePackageJson(fullPath);
          if (pkg) {
            packages.push(pkg);
          } else {
            const subPackages = scanDirectory(fullPath);
            packages.push(...subPackages);
          }
        }
      } catch {
        // 跳过无法访问的目录
      }
    }
  } catch {
    // 跳过无法访问的目录
  }

  return packages;
}

function checkPackage(pkg: PackageInfo): Violation | null {
  const violations: string[] = [];

  for (const depName of Object.keys(pkg.dependencies)) {
    if (!isInternalPackage(depName) && !EXEMPT_PACKAGES.has(depName)) {
      violations.push(`第三方运行时依赖: ${depName}@${pkg.dependencies[depName]}`);
    }
  }

  if (violations.length > 0) {
    return {
      packageName: pkg.name,
      packagePath: pkg.path,
      violations,
    };
  }

  return null;
}

function printReport(violations: Violation[]): void {
  console.log('\n========================================');
  console.log('       LytJS 零依赖规范校验报告');
  console.log('========================================\n');

  if (violations.length === 0) {
    console.log('✅ 所有包均符合零依赖规范！');
    console.log('   - 所有运行时 dependencies 均为内部包 (@lytjs/*)');
    console.log('   - 无第三方运行时依赖\n');
    return;
  }

  console.log(`❌ 发现 ${violations.length} 个包违反零依赖规范：\n`);

  for (const violation of violations) {
    console.log(`📦 ${violation.packageName}`);
    console.log(`   路径: ${relative(process.cwd(), violation.packagePath)}`);

    for (const v of violation.violations) {
      console.log(`   ❌ ${v}`);
    }
    console.log();
  }

  console.log('----------------------------------------');
  console.log('规范说明：');
  console.log('  - 所有 L0-L6 层包的 dependencies 必须只包含 @lytjs/* 内部包');
  console.log('  - 仅允许 devDependencies 中使用第三方依赖');
  console.log('  - 第三方工具请使用 @lytjs/common-* 系列工具包替代');
  console.log('----------------------------------------\n');
}

function main(): void {
  console.log('开始扫描包...\n');

  const allPackages: PackageInfo[] = [];

  for (const target of SCAN_TARGETS) {
    const targetPath = join(process.cwd(), target);

    try {
      const packages = scanDirectory(targetPath);
      allPackages.push(...packages);
    } catch {
      console.warn(`警告: 无法扫描目录 ${target}`);
    }
  }

  console.log(`扫描到 ${allPackages.length} 个包\n`);

  const violations: Violation[] = [];

  for (const pkg of allPackages) {
    const violation = checkPackage(pkg);
    if (violation) {
      violations.push(violation);
    }
  }

  printReport(violations);

  if (violations.length > 0) {
    process.exit(1);
  }
}

main();
```

## 脚本开发规范

### 必须遵守

1. **零第三方依赖**：只使用 Node.js 原生 API
2. **中文注释**：所有脚本必须有中文注释和文档
3. **错误处理**：必须有完善的错误处理和用户友好的提示
4. **清晰输出**：输出必须清晰、易读，使用 emoji 标记状态
5. **退出码**：成功时 `process.exit(0)`，失败时 `process.exit(1)`

### 推荐实践

1. **模块化**：将复杂逻辑拆分为独立函数
2. **配置分离**：使用常量配置可调整的参数
3. **类型安全**：使用 TypeScript 类型定义
4. **可测试性**：函数应该易于测试
5. **进度反馈**：长时间运行的脚本应该提供进度反馈

## 共享工具

项目提供了 `shared.ts` 作为共享工具模块，可以复用常用功能：

```typescript
import { someUtilityFunction } from './shared';
```

## 测试脚本

### 测试位置

测试文件位于 `scripts/tests/` 目录下。

### 测试模板

```typescript
import { describe, it, expect, vi } from 'vitest';
import { functionToTest } from '../my-script';

describe('my-script', () => {
  it('should work correctly', () => {
    const result = functionToTest('input');
    expect(result).toEqual('expected');
  });
});
```

### 运行测试

```bash
pnpm my-script:test
# 或
vitest run scripts/tests/my-script.test.ts
```

## 常用 Node.js 原生 API

### 文件系统

```typescript
import {
  readFileSync,
  writeFileSync,
  readdirSync,
  statSync,
  existsSync
} from 'node:fs';
import { join, relative, dirname, basename } from 'node:path';
import { fileURLToPath } from 'node:url';
```

### 子进程

```typescript
import { execSync, spawnSync } from 'node:child_process';
```

### 网络

```typescript
import { request } from 'node:https';
```

### 其他

```typescript
import { process } from 'node:process';
import { Buffer } from 'node:buffer';
```

## 运行脚本

### 使用 tsx 运行 TypeScript 脚本

```bash
tsx scripts/my-script.ts
```

### 使用 package.json 脚本

```bash
pnpm my-script
```

## 常见问题

### Q: 脚本可以使用第三方依赖吗？

A: **不可以**。工程化脚本也应该遵循零依赖原则，只使用 Node.js 原生 API。如果确实需要，可以使用 `@lytjs/common-*` 系列工具包。

### Q: 如何处理跨平台路径问题？

A: 使用 `node:path` 模块的 `join()` 和其他路径处理函数，不要手动拼接路径。

### Q: 脚本需要支持哪些平台？

A: 脚本应该支持 Windows、macOS 和 Linux。注意换行符、路径分隔符等平台差异。

### Q: 如何调试脚本？

A:
1. 添加 `console.log` 输出中间状态
2. 使用 VS Code 的调试功能
3. 在 `scripts/` 目录下运行 `node --inspect-brk my-script.ts`

## 参考脚本

- [零依赖检查](file:///f:/trae/lytjs/scripts/check-zero-deps.ts)
- [循环依赖检查](file:///f:/trae/lytjs/scripts/check-circular.ts)
- [版本同步](file:///f:/trae/lytjs/scripts/sync-versions.ts)
- [共享工具](file:///f:/trae/lytjs/scripts/shared.ts)

## 详细文档

完整的开发指南请参考：`docs/development/DEVELOPMENT_SKILLS.md` Skill 7
