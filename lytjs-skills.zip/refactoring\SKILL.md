---
name: refactoring
description: LytJS 重构最佳实践指南，提供安全重构方法和常见重构模式
---
# LytJS 重构最佳实践指南

## 描述

为 LytJS 项目提供代码重构的最佳实践和安全重构方法，确保在不破坏功能的前提下提升代码质量。

## 何时使用

- 需要改进现有代码结构时
- 需要消除代码重复时
- 需要提升代码可维护性时
- 代码出现坏味道时

## 重构前准备

### 确保有完整的测试覆盖

```bash
# 运行相关包的测试
cd packages/xxx && pnpm test

# 确保所有测试通过
```

### 了解重构范围

- 确定重构影响的范围
- 识别相关的依赖关系
- 制定重构计划

### 创建安全网

```bash
# 创建功能分支
git checkout -b refactor/xxx

# 确保当前状态干净
git status
```

## 常见重构模式

### 1. 提取函数（Extract Function）

**适用场景：** 函数过长或有重复代码

```typescript
// 重构前
function processOrder(order: Order) {
  // 验证订单
  if (!order.id) throw new Error('缺少订单ID');
  if (!order.items || order.items.length === 0) throw new Error('订单为空');

  // 计算总价
  let total = 0;
  for (const item of order.items) {
    total += item.price * item.quantity;
  }

  // 应用折扣
  if (order.coupon) {
    total = total * 0.9;
  }

  return total;
}

// 重构后
function processOrder(order: Order) {
  validateOrder(order);
  let total = calculateTotal(order);
  total = applyDiscount(total, order.coupon);
  return total;
}

function validateOrder(order: Order) {
  if (!order.id) throw new Error('缺少订单ID');
  if (!order.items || order.items.length === 0) throw new Error('订单为空');
}

function calculateTotal(order: Order): number {
  return order.items.reduce((sum, item) => sum + item.price * item.quantity, 0);
}

function applyDiscount(total: number, coupon?: string): number {
  return coupon ? total * 0.9 : total;
}
```

### 2. 合并重复代码（Consolidate Duplicate Code）

**适用场景：** 多处有相似的代码

```typescript
// 重构前
function updateUser(user: User) {
  if (!user.id) throw new Error('缺少用户ID');
  if (!user.name) throw new Error('缺少用户名');
  // 更新用户
}

function createUser(user: User) {
  if (!user.id) throw new Error('缺少用户ID');
  if (!user.name) throw new Error('缺少用户名');
  // 创建用户
}

// 重构后
function validateUser(user: User) {
  if (!user.id) throw new Error('缺少用户ID');
  if (!user.name) throw new Error('缺少用户名');
}

function updateUser(user: User) {
  validateUser(user);
  // 更新用户
}

function createUser(user: User) {
  validateUser(user);
  // 创建用户
}
```

### 3. 替换魔法数字（Replace Magic Number）

**适用场景：** 代码中有不明意义的数字

```typescript
// 重构前
if (status === 0) {
  // 处理
}

// 重构后
const STATUS_INACTIVE = 0;
const STATUS_ACTIVE = 1;

if (status === STATUS_INACTIVE) {
  // 处理
}
```

### 4. 简化条件表达式

**适用场景：** 复杂的 if-else 嵌套

```typescript
// 重构前
function getDiscount(user: User) {
  if (user.isVip) {
    if (user.points > 1000) {
      return 0.8;
    } else {
      return 0.9;
    }
  } else {
    return 1;
  }
}

// 重构后
function getDiscount(user: User) {
  if (!user.isVip) return 1;
  if (user.points > 1000) return 0.8;
  return 0.9;
}
```

## 重构安全实践

### 小步重构

每次只做一个小的重构，然后立即测试：

```bash
# 小步骤重构
# 1. 做一个小改动
# 2. 运行测试
pnpm test
# 3. 提交
git commit -m "refactor: xxx"
# 4. 重复
```

### 保持功能不变

重构的黄金法则：
- ✅ 重构后功能必须保持一致
- ✅ 所有测试必须通过
- ✅ 不要在重构时添加新功能

### 频繁测试

```bash
# 每次重构后运行相关测试
cd packages/reactivity && pnpm test
```

## 代码坏味道识别

### 需要重构的信号

| 坏味道 | 描述 | 重构方案 |
| --- | --- | --- |
| 过长函数 | 函数超过 50 行 | 提取函数 |
| 重复代码 | 相同代码出现多次 | 合并重复代码 |
| 过长参数列表 | 参数超过 3 个 | 使用参数对象 |
| 魔法数字 | 不明意义的数字 | 替换为常量 |
| 嵌套过深 | if-else 嵌套超过 3 层 | 简化条件 |
| 过大的类/模块 | 职责过多 | 拆分模块 |

## 性能敏感区域注意事项

在 LytJS 核心包中，重构时需要特别注意：

### 1. 对象池相关代码

```typescript
// 重构时保持对象池的使用方式
const vnode = createVNode(tag, props, children);
// 不要改变对象池的核心逻辑
```

### 2. 响应式更新路径

```typescript
// 重构时避免引入不必要的响应式更新
// 保持原有的更新机制
```

### 3. 热点路径

```typescript
// 在热点路径上的重构要进行性能测试
// 使用基准测试验证性能没有退化
```

## 重构后的验证

### 运行完整测试

```bash
# 运行完整测试
pnpm test

# 运行类型检查
pnpm type-check

# 运行代码检查
pnpm lint:check
```

### 性能验证（如果涉及核心代码）

```bash
# 运行基准测试
cd packages/vdom && pnpm benchmark

# 对比性能指标
```

## 详细文档

- [DEVELOPMENT_GUIDELINES.md](file:///f:/trae/lytjs/docs/development/DEVELOPMENT_GUIDELINES.md) - 完整开发规范
- [ZERO_DEPENDENCY_GUIDE.md](file:///f:/trae/lytjs/docs/development/ZERO_DEPENDENCY_GUIDE.md) - 零依赖指南

