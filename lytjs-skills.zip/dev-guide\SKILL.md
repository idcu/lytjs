---
name: dev-guide
description: LytJS 开发指南，包括项目结构、开发工作流、Git 工作流、构建和测试流程
---
# LytJS 开发指南

## 描述

为 LytJS 项目提供完整的开发指南，包括项目结构、开发工作流、Git 工作流、构建和测试流程。

## 何时使用

- 新开发者加入项目时
- 需要了解开发工作流时
- 需要了解项目结构时
- 开始新功能开发前

## 项目结构

### 核心包（L0-L4）

```
packages/
├── common/                 # L0 基础工具包集合
│   └── packages/
│       ├── common-is/     # 类型检查
│       ├── common-utils/  # 工具函数
│       └── ...
├── reactivity/            # L1 响应式系统
├── vdom/                  # L1 虚拟 DOM
├── compiler/              # L1 模板编译器
├── renderer/              # L2 渲染器
├── component/             # L2 组件系统
├── core/                  # L3 核心运行时
└── plugins/               # L4 官方插件
```

### 生态包（L6）

```
packages/ecosystem/packages/
├── ui/                    # UI 组件库
├── router/                # 路由系统
├── store/                 # 状态管理
├── ssr/                   # 服务端渲染
└── ...
```

### 工程化工具（L7）

```
packages/tools/packages/
├── cli/                   # 命令行工具
└── ...
```

## Git 工作流

### 1. 创建分支

```bash
git checkout -b feature/your-feature-name
```

分支命名规范：
- `feature/xxx` - 新功能
- `fix/xxx` - Bug 修复
- `refactor/xxx` - 代码重构
- `docs/xxx` - 文档更新

### 2. 开发和提交

```bash
# 编写代码
# 确保有完整的测试覆盖

# 运行检查
pnpm lint:check
pnpm type-check
pnpm test

# 提交（如遇内存问题跳过 husky）
git add .
git commit --no-verify -m "feat(scope): 功能描述"
```

### 3. 提交规范

遵循 Conventional Commits 规范：
- `feat(scope):` - 新功能
- `fix(scope):` - Bug 修复
- `refactor(scope):` - 代码重构
- `docs(scope):` - 文档更新
- `test(scope):` - 测试更新
- `chore(scope):` - 构建/工具更新

## 构建流程

### 1. 完整构建

```bash
pnpm build
```

### 2. 构建特定包

```bash
pnpm build --filter @lytjs/reactivity
```

### 3. 开发模式构建

```bash
cd packages/reactivity
pnpm dev
```

## 测试流程

### 1. 运行所有测试

```bash
pnpm test
```

### 2. 运行特定包的测试

```bash
pnpm --filter @lytjs/reactivity test
```

### 3. 运行特定测试文件

```bash
cd packages/reactivity
pnpm test tests/xxx.test.ts
```

### 4. 监听模式

```bash
pnpm test --watch
```

## 代码检查流程

### 1. 运行所有检查

```bash
pnpm lint:check
pnpm type-check
```

### 2. 自动修复

```bash
pnpm lint:fix
```

## 开始新功能开发

### 完整流程

```bash
# 1. 创建分支
git checkout -b feature/your-feature

# 2. 检查项目状态
pnpm type-check

# 3. 开发功能
# 确保类型安全、测试覆盖

# 4. 运行检查
pnpm lint:check
pnpm test

# 5. 提交
git add .
git commit --no-verify -m "feat(scope): 描述"

# 6. 推送
git push origin feature/your-feature
```

## 详细文档

- [AGENTS.md](file:///f:/trae/lytjs/AGENTS.md) - 项目基础规则
- [ROADMAP_NEXT_STEPS.md](file:///f:/trae/lytjs/docs/development/ROADMAP_NEXT_STEPS.md) - 项目路线图
- [DEVELOPMENT_GUIDELINES.md](file:///f:/trae/lytjs/docs/development/DEVELOPMENT_GUIDELINES.md) - 完整开发规范
