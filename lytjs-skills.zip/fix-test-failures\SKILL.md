---
name: fix-test-failures
description: 排查和修复测试运行失败问题，提供常见错误解决方案
---
# fix-test-failures

## 描述

排查和解决 Vitest 测试运行失败的问题，提供标准化的排查流程和常见错误解决方案。

## 何时使用

- 测试运行失败需要排查原因时
- 遇到环境配置问题
- API 签名不匹配或模块导入问题

## 排查流程

1. **确认测试环境**：区分 node 环境 vs jsdom 环境
2. **检查 vitest 配置**：确认使用根目录还是包目录的配置
3. **构建依赖包**：确保依赖包已构建
   ```bash
   pnpm build
   ```
4. **检查 mock 正确性**：验证 mock 函数和模块是否正确
5. **检查 API 签名**：确认测试代码与源码实现一致
6. **路径别名问题**：尝试直接导入构建后文件

## 常见问题与解决方案

| 错误信息 | 解决方案 |
|---------|---------|
| `document is not defined` | 需要使用 jsdom 环境配置 |
| `Cannot find module` | 先构建依赖包 `pnpm build` |
| `process is not defined` | 检查 Node.js 与 vitest 版本兼容性 |
| 子路径导出无法解析 | 使用 `require()` 导入构建后文件 |

## 验证流程

1. 先运行单个测试文件定位问题
2. 再运行完整测试套件验证
3. 使用 `--reporter verbose` 查看详细输出

## 命令

```bash
pnpm --filter {package} test
```
