# LytJS DevTools 开发指南

## 描述

为 LytJS 项目提供 DevTools 功能开发的完整指南，包括内嵌面板和浏览器扩展的开发。

## 何时使用

- 需要扩展 DevTools 功能时
- 需要添加新的调试面板时
- 需要开发浏览器扩展功能时
- 需要了解 DevTools 架构时

## DevTools 架构

### 双模块架构

LytJS DevTools 包含两个独立模块：

```
packages/
├── ecosystem/packages/devtools/       # 轻量级内嵌面板（面向开发者快速调试）
└── tools/packages/devtools/          # 浏览器扩展后端（提供高级调试能力）
```

### 内嵌面板 (ecosystem/devtools)

**位置**: [packages/ecosystem/packages/devtools/](file:///f:/trae/lytjs/packages/ecosystem/packages/devtools/)

**特点**:
- 轻量级，直接集成到应用中
- 快速调试，无需浏览器扩展
- 面向开发者日常开发使用

**核心文件**:
```
src/
├── devtools.ts           # 主面板渲染逻辑
├── signalsInspector.ts    # Signal 检查器
├── componentTree.ts       # 组件树
├── storeInspector.ts      # Store 检查器
├── routeInspector.ts      # 路由检查器
├── performance.ts         # 性能面板
├── benchmark.ts           # 基准测试
├── types.ts               # 类型定义
└── index.ts               # 统一导出
```

**开发指南**:
- 直接修改 `src/devtools.ts` 中的面板渲染逻辑
- 新增功能需同步更新 `src/index.ts` 导出
- 新增功能需添加测试文件 `tests/index.test.ts`

### 浏览器扩展 (tools/devtools)

**位置**: [packages/tools/packages/devtools/](file:///f:/trae/lytjs/packages/tools/packages/devtools/)

**特点**:
- 完整的浏览器扩展
- 提供高级调试能力
- 独立的 UI 面板

**核心文件**:
```
src/
├── panel/
│   ├── index.ts          # 主面板
│   ├── performance.ts    # 性能面板
│   ├── state-editor.ts   # 状态编辑器
│   └── time-travel.ts    # 时间旅行调试
├── api.ts                # API 层
├── bridge.ts             # 与应用通信桥接
├── component-tree.ts     # 组件树
├── events.ts             # 事件系统
├── signals.ts            # Signals 处理
├── snapshots.ts          # 状态快照
├── state.ts              # 状态管理
├── router-integration.ts # 路由集成
├── store-integration.ts  # Store 集成
├── types.ts              # 类型定义
└── index.ts              # 统一导出

extension/
├── icons/               # 扩展图标
├── panel.js             # 面板 UI
├── panel.css            # 面板样式
└── injected.js          # 注入脚本
```

**开发指南**:
- 在对应子模块（signals/events/snapshots/panel/\*）中添加功能
- 新增功能需同步更新 `src/index.ts` 导出
- 新增功能需添加测试文件 `tests/index.test.ts`

## 内嵌面板开发

### 添加新面板

1. 在 `src/` 下创建新的面板文件，例如 `myFeature.ts`
2. 在 `devtools.ts` 中集成新面板
3. 在 `index.ts` 中导出新功能

**示例**:

```typescript
// src/myFeature.ts
import { signal } from '@lytjs/reactivity';

export function createMyFeaturePanel() {
  const state = signal('initial');
  
  return {
    get state() { return state(); },
    update: (value: string) => state.set(value),
  };
}

// 在 devtools.ts 中集成
import { createMyFeaturePanel } from './myFeature';

export function createDevTools() {
  // ... 现有功能
  const myFeature = createMyFeaturePanel();
  
  return {
    // ... 现有导出
    myFeature,
  };
}
```

### 测试内嵌面板

```bash
cd packages/ecosystem/packages/devtools
pnpm test
pnpm build
```

## 浏览器扩展开发

### 添加新功能模块

1. 在 `src/` 下创建新的功能文件
2. 在 `src/panel/` 下创建对应的面板 UI
3. 在 `src/index.ts` 中导出
4. 在 `extension/panel.js` 中集成 UI

### 浏览器扩展构建

```bash
cd packages/tools/packages/devtools
pnpm build
```

### 加载扩展到浏览器

1. 打开 Chrome/Edge 浏览器
2. 访问 `chrome://extensions/`
3. 开启「开发者模式」
4. 点击「加载已解压的扩展程序」
5. 选择 `extension/` 目录

## 通用开发规范

### 必须遵守

1. **类型安全**: 使用 TypeScript 严格模式，不使用 `any`
2. **中文注释**: 公共 API 必须有中文 JSDoc
3. **测试覆盖**: 新功能必须有对应的测试
4. **零依赖**: 运行时代码不引入第三方依赖

### 推荐实践

1. **模块化**: 将功能拆分为独立模块
2. **双向通信**: 使用 bridge 进行应用与 DevTools 的通信
3. **性能监控**: 新功能应该对应用性能影响最小
4. **用户体验**: 提供清晰的 UI 和操作反馈

## DevTools 功能概览

### 内嵌面板功能

| 功能 | 文件 | 描述 |
|-----|------|------|
| Signals 检查器 | signalsInspector.ts | 查看和调试响应式信号 |
| 组件树 | componentTree.ts | 查看应用组件层级 |
| Store 检查器 | storeInspector.ts | 查看 Store 状态 |
| 路由检查器 | routeInspector.ts | 调试路由状态 |
| 性能面板 | performance.ts | 性能监控和分析 |
| 基准测试 | benchmark.ts | 性能基准测试 |

### 浏览器扩展功能

| 功能 | 文件 | 描述 |
|-----|------|------|
| Signals 处理 | signals.ts | 高级信号调试 |
| 状态快照 | snapshots.ts | 保存和恢复状态 |
| 时间旅行 | panel/time-travel.ts | 时间旅行调试 |
| 状态编辑器 | panel/state-editor.ts | 直接编辑状态 |
| 性能面板 | panel/performance.ts | 详细性能分析 |
| 事件系统 | events.ts | 事件追踪 |

## 测试 DevTools

### 运行测试

```bash
# 内嵌面板测试
cd packages/ecosystem/packages/devtools
pnpm test

# 浏览器扩展测试
cd packages/tools/packages/devtools
pnpm test
```

### 测试覆盖要求

- 核心功能测试覆盖率 ≥ 80%
- 新增功能必须有对应的测试

## 常见问题

### Q: 如何在应用中集成内嵌 DevTools？

A:

```typescript
import { createDevTools } from '@lytjs/devtools';

const app = createApp(App);
const devtools = createDevTools();
app.use(devtools);
app.mount('#app');
```

### Q: 如何在开发模式下自动启用 DevTools？

A: 在应用入口添加：

```typescript
if (__DEV__) {
  const devtools = createDevTools();
  app.use(devtools);
}
```

### Q: 浏览器扩展如何与应用通信？

A: 通过 `bridge.ts` 中的桥接机制，使用 postMessage 进行通信。

## 参考文件

- [内嵌面板实现](file:///f:/trae/lytjs/packages/ecosystem/packages/devtools/src/devtools.ts)
- [浏览器扩展实现](file:///f:/trae/lytjs/packages/tools/packages/devtools/src/index.ts)
- [类型定义](file:///f:/trae/lytjs/packages/ecosystem/packages/devtools/src/types.ts)

## 详细文档

完整的开发指南请参考: `docs/development/DEVELOPMENT_SKILLS.md` Skill 4
