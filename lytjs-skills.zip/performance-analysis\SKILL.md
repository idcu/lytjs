---
name: performance-analysis
description: LytJS 性能分析指南，提供性能分析方法和常见性能瓶颈识别
---
# LytJS 性能分析指南

## 描述

为 LytJS 项目提供性能分析、瓶颈识别和性能基准测试的最佳实践，帮助开发者找到性能问题并进行优化。

## 何时使用

- 需要分析代码性能时
- 需要识别性能瓶颈时
- 需要进行性能基准测试时
- 优化前后需要对比性能时

## 性能分析方法

### 1. 使用基准测试

```bash
# 运行基准测试
cd packages/vdom && pnpm benchmark
```

### 2. 使用 console.time

```typescript
console.time('渲染1000个元素');
// 执行要测试的代码
render1000Elements();
console.timeEnd('渲染1000个元素');
```

### 3. 使用 performance API

```typescript
const start = performance.now();
// 执行代码
const end = performance.now();
console.log(`耗时: ${end - start}ms`);
```

## 常见性能瓶颈

### 1. 频繁创建和销毁对象

**问题：**
```typescript
// 每次渲染都创建新对象
function render() {
  const vnode = { tag: 'div', props: {}, children: [] };
  // ...
}
```

**分析：**
```typescript
// 使用对象池监控
console.log('对象池使用情况:', objectPoolStats);
// 检查对象创建频率
```

**优化方向：** 参考 performance-optimization 技能的对象池优化

### 2. 不必要的响应式更新

**问题：**
```typescript
// 频繁触发响应式更新
effect(() => {
  // 每次状态变化都执行重渲染
  render();
});
```

**分析：**
```typescript
// 检查 effect 触发频率
console.log('Effect 触发次数:', effectCount);
// 检查依赖追踪
```

### 3. 不必要的计算

**问题：**
```typescript
// 每次访问都重新计算
function getDerivedValue() {
  return heavyComputation();
}
```

**分析：**
```typescript
// 使用计算属性缓存
const derived = computed(() => heavyComputation());
```

### 4. 深度遍历或递归

**问题：**
```typescript
// 深度遍历大型对象树
function deepTraverse(obj) {
  for (const key in obj) {
    if (typeof obj[key] === 'object') {
      deepTraverse(obj[key]);
    }
  }
}
```

**分析：**
```typescript
// 检查递归深度
console.log('递归深度:', recursionDepth);
// 考虑优化算法
```

## 性能测试流程

### 1. 建立基准线

```bash
# 在优化前运行基准测试
cd packages/vdom && pnpm benchmark
# 记录结果
```

### 2. 进行修改和优化

按照性能优化指南进行修改

### 3. 验证性能

```bash
# 再次运行基准测试
cd packages/vdom && pnpm benchmark
# 对比结果
```

### 4. 提交优化

```bash
git commit -m "perf: 优化 xxx 性能"
```

## 性能分析检查清单

- [ ] 运行了基准测试
- [ ] 识别了性能瓶颈
- [ ] 有明确的优化方案
- [ ] 优化后进行了性能验证
- [ ] 性能有明显提升（建议 > 10%）
- [ ] 没有引入新的问题
- [ ] 所有测试通过

## 热点路径识别

### LytJS 核心热点路径

1. **VNode 创建和销毁路径**
   - `createVNode()` - 检查对象池使用
   - VNode 生命周期 - 检查不必要的操作

2. **响应式更新路径**
   - Signal 通知 - 检查批量更新
   - Effect 执行 - 检查依赖追踪

3. **DOM 更新路径**
   - Diff 算法 - 检查比较逻辑
   - Patch 操作 - 检查批量更新

## 详细文档

- [lytjs-performance-optimization](file:///f:/trae/lytjs/.trae/skills/performance-optimization/SKILL.md) - 性能优化指南
- [ARCHITECTURE.md](file:///f:/trae/lytjs/docs/development/ARCHITECTURE.md) - 架构设计文档

