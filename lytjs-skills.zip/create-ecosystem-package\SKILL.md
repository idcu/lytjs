---
name: create-ecosystem-package
description: 在 ecosystem 下创建新的生态系统包，包含完整的目录结构和配置模板
---
# create-ecosystem-package

## 描述

在 `packages/ecosystem/packages/` 目录下创建新的生态系统包，包含完整的项目结构和配置。

## 何时使用

- 需要新增生态系统包（如新的 UI 组件库、工具包等）
- 扩展 LytJS 生态系统功能

## 创建步骤

### 1. 创建目录结构

```
packages/ecosystem/packages/{package-name}/
├── src/
│   └── index.ts
├── tests/
│   └── index.test.ts
├── package.json
├── tsconfig.json
└── tsup.config.ts
```

### 2. package.json 模板

```json
{
  "name": "@lytjs/{package-name}",
  "version": "6.0.0",
  "type": "module",
  "main": "./dist/index.mjs",
  "types": "./dist/index.d.ts",
  "exports": {
    ".": {
      "import": "./dist/index.mjs",
      "types": "./dist/index.d.ts"
    }
  },
  "scripts": {
    "build": "tsup",
    "test": "vitest run",
    "dev": "tsup --watch"
  }
}
```

### 3. tsup.config.ts 配置

确保启用 `dts: true` 以生成类型声明文件：

```typescript
import { defineConfig } from 'tsup';

export default defineConfig({
  entry: ['src/index.ts'],
  format: ['esm'],
  dts: true,
  splitting: false,
  sourcemap: true,
  clean: true,
});
```

### 4. 统一导出

在 `src/index.ts` 中统一导出所有公共 API：

```typescript
export * from './component';
export { default as Plugin } from './plugin';
```

### 5. 更新根配置

- 在根 `vitest.config.ts` 中添加别名（如需要）
- 在根 `package.json` 中添加构建脚本
- 更新 `pnpm-workspace.yaml`

## 注意事项

- 遵循零依赖原则，优先使用 `@lytjs/common-*` 包
- 编写完整的测试用例
- 确保类型安全，无 any 类型（测试除外）
