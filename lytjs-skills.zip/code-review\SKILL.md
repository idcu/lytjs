---
name: code-review
description: LytJS 代码审查指南，提供代码审查检查清单和最佳实践
---
# LytJS 代码审查指南

## 描述

为 LytJS 项目提供代码审查的最佳实践和检查清单，确保代码质量和一致性。

## 何时使用

- 提交 Pull Request 前进行自我审查
- 审查他人代码时
- 需要检查代码质量时

## 代码审查检查清单

### 功能正确性

- [ ] 代码逻辑是否正确实现了需求
- [ ] 边界条件是否处理
- [ ] 错误处理是否完善
- [ ] 是否有未处理的 null/undefined

### 代码质量

- [ ] 函数是否简短精炼（建议 < 50 行）
- [ ] 是否有重复代码可抽取
- [ ] 变量和函数命名是否清晰
- [ ] 是否有过度复杂的逻辑

### 类型安全

- [ ] 是否避免使用 `any` 类型
- [ ] 类型定义是否完整准确
- [ ] 是否使用了 TypeScript 严格模式

### 零依赖原则

- [ ] 核心包是否未引入第三方依赖
- [ ] 是否合理使用已有的工具函数
- [ ] 是否遵循了 8 层架构的依赖规则

### 测试覆盖

- [ ] 新增功能是否有对应测试
- [ ] 边界条件是否有测试覆盖
- [ ] 所有测试是否都能通过

### 文档和注释

- [ ] 公共 API 是否有 JSDoc 注释
- [ ] 复杂逻辑是否有中文注释
- [ ] README 或相关文档是否已更新

### 性能考虑

- [ ] 是否有不必要的重复计算
- [ ] 对象池是否正确使用
- [ ] 响应式更新是否高效

### Git 提交

- [ ] 提交信息是否遵循 Conventional Commits
- [ ] 是否在正确的分支上
- [ ] 是否有过大的提交（建议拆分成小提交）

## 审查流程

### 自我审查

在提交 PR 前，先进行自我审查：

```bash
# 查看变更
git diff

# 运行检查
pnpm lint:check
pnpm type-check
pnpm test

# 确保所有检查通过
```

### 代码审查要点

#### 1. 先看整体，再看细节

- 理解修改的目的和范围
- 检查架构是否合理
- 然后再看具体实现

#### 2. 建设性反馈

使用建设性的语言：

```
✅ 推荐：这里逻辑很清晰，可以考虑...
❌ 避免：这个代码写得太差了
```

#### 3. 关注重要问题

优先级排序：
1. 🔴 功能正确性问题
2. 🔴 安全问题
3. 🟡 架构/设计问题
4. 🟡 性能问题
5. 🟢 代码风格问题

## 常见问题和建议

### 避免过度设计

```typescript
// ✅ 推荐：简单直接
function add(a: number, b: number): number {
  return a + b;
}

// ❌ 避免：过度设计
class Calculator {
  private a: number;
  private b: number;

  constructor(a: number, b: number) {
    this.a = a;
    this.b = b;
  }

  add(): number {
    return this.a + this.b;
  }
}
```

### 函数参数建议

```typescript
// ✅ 推荐：参数不超过 3 个
function createUser(name: string, age: number, email: string) { /* ... */ }

// ✅ 如果需要更多参数，使用对象
function createUser(options: CreateUserOptions) { /* ... */ }
```

### 错误处理建议

```typescript
// ✅ 推荐：明确的错误处理
try {
  const result = doSomething();
  return result;
} catch (error) {
  console.error('操作失败:', error);
  throw new Error('自定义错误信息');
}
```

## 性能审查要点

### 检查对象池使用

```typescript
// ✅ 推荐：使用对象池
const vnode = createVNode(tag, props, children);

// 检查是否有频繁创建和销毁的对象
// 考虑是否可以用对象池优化
```

### 检查响应式更新

```typescript
// ✅ 推荐：避免不必要的响应式更新
// 检查是否有过度的 watch/effect
```

## 详细文档

- [DEVELOPMENT_GUIDELINES.md](file:///f:/trae/lytjs/docs/development/DEVELOPMENT_GUIDELINES.md) - 完整开发规范
- [ARCHITECTURE.md](file:///f:/trae/lytjs/docs/development/ARCHITECTURE.md) - 架构设计文档
