# LytJS 中文文档和编码规范指南

## 描述

为 LytJS 项目提供中文文档写作、代码注释和文件编码的完整规范指南。

## 何时使用

- 需要编写或更新文档时
- 需要添加或修改代码注释时
- 遇到文件编码问题时
- 检查文档和注释规范时

## 文件编码规范

### 编码要求

所有源文件必须使用 **UTF-8 编码，无 BOM**

| 文件类型 | 编码要求 |
| --- | --- |
| `.ts`, `.tsx`, `.js`, `.jsx` | UTF-8 无 BOM |
| `.md`, `.mdx` | UTF-8 无 BOM |
| `.json` | UTF-8 无 BOM |
| `.html`, `.css`, `.scss` | UTF-8 无 BOM |

### 换行符规范

- Windows: CRLF (`\r\n`)
- Linux/macOS: LF (`\n`)

**Git 已配置自动处理**（见 .gitattributes），无需手动设置。

### 文件头部示例

```typescript
/**
 * @lytjs/包名
 * 包功能描述
 *
 * @author LytJS Team
 * @since 6.0.0
 */

// 代码开始...
```

## 文档语言规范

### 基本原则

✅ **所有文档使用中文**，包括：
- README.md
- API 文档
- 架构文档
- 代码注释
- 提交信息

✅ **保留必要的英文术语**，如：
- API, SDK, UI, CLI
- React, Vue, TypeScript
- HTTP, JSON, URL
- 变量名、函数名（如 `ref`, `computed`）

### 术语一致性

建立统一的术语表，避免混淆：

| 推荐 | 不推荐 | 说明 |
| --- | --- | --- |
| 组件 | 元件 | 前端通用译法 |
| 响应式 | 反应式 | 保持与 Vue 一致 |
| 虚拟 DOM | VDOM | 可混用，首次出现注明 |
| 钩子 | Hook | 可混用 |
| 属性 | Props | 可混用 |
| 插槽 | Slot | 可混用 |

### 文档写作规范

#### 标题层级

```markdown
# 一级标题
## 二级标题
### 三级标题
#### 四级标题
```

#### 代码示例

```typescript
// ✅ 推荐：代码注释也使用中文
/**
 * 创建响应式引用
 * @param value - 初始值
 */
function ref(value) { /* ... */ }
```

## 注释规范

### JSDoc 注释规范

公共 API 必须有完整的 JSDoc 注释：

```typescript
/**
 * 创建响应式引用（Ref）
 *
 * @description
 * 将普通值包装为响应式引用对象，可通过 .value 属性访问和修改值。
 *
 * @param value - 初始值
 * @returns 响应式引用对象
 *
 * @example
 * ```typescript
 * const count = ref(0);
 * console.log(count.value); // 0
 * count.value++;
 * console.log(count.value); // 1
 * ```
 *
 * @template T - 值的类型
 * @see reactive - 创建响应式对象
 * @see computed - 创建计算属性
 */
export function ref<T>(value: T): Ref<T> {
  // 实现
}
```

### 单行注释

```typescript
// ✅ 推荐：注释使用中文
// 检查是否为空值
const isEmpty = value == null;

// ❌ 避免：英文注释
// Check if value is empty
```

### 内联注释

```typescript
// ✅ 推荐
const result = processData(input); // 处理输入数据

// 复杂逻辑分段注释
function complexAlgorithm(data: Data): Result {
  // 步骤 1: 数据验证
  if (!isValid(data)) {
    throw new Error('数据无效');
  }

  // 步骤 2: 数据预处理
  const processed = preprocess(data);

  // 步骤 3: 核心计算
  const computed = compute(processed);

  // 步骤 4: 结果格式化
  return formatResult(computed);
}
```

### TODO 和 FIXME 注释

```typescript
// TODO: 待实现功能 - 2026-05-12
// 说明待实现的具体内容

// FIXME: 临时解决方案 - 2026-05-12
// 说明问题和更好的解决方案
```

## 常见问题解决

### 乱码问题

#### 症状
```
- 文件打开显示乱码
- 编译出现 SyntaxError
- Git diff 显示奇怪字符
```

#### 解决步骤

1. **确认文件编码**
```bash
file -i 问题文件.ts
```

2. **转换为 UTF-8**
```bash
# 如果是 GBK
iconv -f GBK -t UTF-8 问题文件.ts > 问题文件.ts.tmp
mv 问题文件.ts.tmp 问题文件.ts

# 或者使用 VS Code：
# 右下角点击编码 -> 通过编码保存 -> UTF-8
```

3. **验证修复**
```bash
file -i 问题文件.ts
# 应该显示 charset=utf-8
```

### Git 换行符问题

#### 症状
```
warning: LF will be replaced by CRLF in ...
```

#### 解决方案

项目已配置 `.gitattributes`，无需担心。

如需手动设置：
```bash
# Windows 用户
git config --global core.autocrlf true

# Linux/macOS 用户
git config --global core.autocrlf input
```

### BOM 头问题

#### 症状
```typescript
// 文件开头出现 ï»¿ 或其他奇怪字符
```

#### 解决方案

```bash
# 删除 BOM（使用 sed）
sed -i '1s/^\xEF\xBB\xBF//' 文件.ts

# 或使用 VS Code：
# 右下角点击编码 -> 通过编码保存 -> UTF-8（选择"UTF-8"而不是"UTF-8 with BOM"）
```

## 快速检查清单

在提交代码前，检查以下项目：

- [ ] 所有 README.md 已使用中文
- [ ] 所有 API 文档已使用中文
- [ ] 所有代码注释已使用中文
- [ ] 所有文件编码为 UTF-8
- [ ] 所有文件无 BOM 头
- [ ] 术语使用一致
- [ ] JSDoc 注释完整
- [ ] 代码示例注释为中文
- [ ] 提交信息为中文

## 详细文档

完整的中文文档和编码规范请参考：
[CHINESE_DOCS_GUIDE.md](file:///f:/trae/lytjs/docs/development/CHINESE_DOCS_GUIDE.md)
