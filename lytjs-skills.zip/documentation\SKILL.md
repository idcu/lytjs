---
name: documentation
description: LytJS 文档生成指南，包括 JSDoc 注释规范、README 文档结构、API 文档生成等
---
# LytJS 文档生成指南

## 描述

为 LytJS 项目提供文档写作和 API 文档生成的最佳实践，确保文档质量和一致性。

## 何时使用

- 需要编写 API 文档时
- 需要更新 README 时
- 需要生成 API 参考文档时

## JSDoc 注释规范

### 公共 API 必须有完整 JSDoc

```typescript
/**
 * 创建响应式引用（Ref）
 *
 * @description
 * 将普通值包装为响应式引用对象，可通过 .value 属性访问和修改值。
 * 当值改变时，会自动触发相关的响应式更新。
 *
 * @param value - 初始值
 * @returns 响应式引用对象
 *
 * @example
 * ```typescript
 * const count = ref(0);
 * console.log(count.value); // 0
 *
 * // 修改值
 * count.value++;
 * console.log(count.value); // 1
 *
 * // 响应式更新
 * effect(() => {
 *   console.log('count changed:', count.value);
 * });
 * ```
 *
 * @template T - 值的类型
 * @see reactive - 创建响应式对象
 * @see computed - 创建计算属性
 * @since 6.0.0
 */
export function ref<T>(value: T): Ref<T> {
  // 实现
}
```

### 必填标签

- `@description` - 详细描述
- `@param` - 参数说明
- `@returns` - 返回值说明
- `@example` - 使用示例
- `@see` - 相关 API 链接
- `@since` -