---
name: fix-type-safety
description: 修复 UI 组件类型错误和 PropType 问题，适用于类型检查失败时使用
---
# fix-type-safety

## 描述

用于修复 UI 组件中的类型错误，特别是 PropType 类型转换问题。

## 何时使用

当 `pnpm type-check` 报类型错误时调用此技能，特别是以下情况：
- PropType 类型转换错误
- PropType 未导出
- 类型导入缺失

## 常见问题与修复

### 1. PropType 类型转换错误

```typescript
// ❌ 错误写法
size: { type: [Number, String] as PropType<number | string> }

// ✅ 正确写法
size: { type: [Number, String] as unknown as PropType<number | string> }
```

### 2. PropType 未导出

需要修改文件：`packages/component/src/index.ts`

```typescript
// 添加到文件末尾
export type { PropType } from './types';
```

重新构建组件包：
```bash
pnpm --filter @lytjs/component build
```

### 3. 类型导入缺失

确保导入所有需要的类型：
```typescript
import type { LinkProps, LinkSlots, LinkSetupProps } from './types';
```

## 需要修复的组件列表（20+）

Avatar, Card, Carousel, CarouselItem, CheckboxGroup, Link, Popconfirm, Progress, RadioGroup, RichTextEditor, Slider, Step, Steps, TimePicker, Timeline, TimelineItem, Toast, Transfer, TreeSelect

## 验证命令

```bash
pnpm type-check
pnpm --filter @lytjs/ui test
```

