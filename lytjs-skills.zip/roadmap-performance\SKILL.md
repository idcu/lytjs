---
name: roadmap-performance
description: LytJS 路线图维护指南，提供项目状态检查和任务更新流程
---
# LytJS 路线图维护指南

## 描述

为 LytJS 项目提供 ROADMAP_NEXT_STEPS.md 的维护流程，包括任务选择、状态更新、项目状态检查等核心功能。

## 何时使用

- 查看或完成任务后需要更新 ROADMAP_NEXT_STEPS.md 时
- 开始新开发任务前需要检查项目状态时
- 需要了解当前项目优先级和进度时

## ROADMAP 维护最佳实践

### 任务状态标记

使用以下 emoji 清晰标记任务状态：

- ✅ **已完成**：全部完成的任务
- 🔄 **进行中**：正在处理的任务
- 🔴 **高优先级**：影响生产稳定性的任务
- 🟡 **中优先级**：提升用户体验的任务
- 🟢 **低优先级**：生态建设等任务
- ⏸️ **暂缓**：当前不需要投入资源的任务

### 定期审查和更新

定期（建议每月或每季度）审查 ROADMAP_NEXT_STEPS.md 文档：

1. **状态标记更新**：及时标记已完成的任务
2. **优先级调整**：根据项目进展调整任务优先级
3. **内容清理**：将已完成的任务历史移至 CHANGELOG.md
4. **下一步建议**：更新下一个阶段的工作重点

### 关键检查点

在更新 roadmap 前确认：
- ✅ 所有验收标准是否符合实际完成情况
- ✅ 任务状态标记是否准确
- ✅ 下一步建议是否及时更新

## 项目状态检查流程

开始任何开发任务前，按以下顺序快速检查项目状态：

```bash
# 1. Git 状态检查
git status
git branch

# 2. 类型检查（快速验证项目健康度）
pnpm type-check

# 3. 关键包测试（可选，根据需要）
cd packages/reactivity && pnpm test
```

## 任务选择与规划

查看 [ROADMAP_NEXT_STEPS.md](file:///f:/trae/lytjs/docs/development/ROADMAP_NEXT_STEPS.md)，选择合适的任务：

- 🔴 **高优先级**：核心优势、用户痛点、生产稳定性
- 🟡 **中优先级**：生态建设、体验优化、功能完善
- 🟢 **低优先级**：长期探索、创新实验

## ROADMAP 更新流程

完成任务后，及时更新 ROADMAP_NEXT_STEPS.md：

1. 标记任务状态为 ✅ 已完成
2. 更新验收标准（如有变更）
3. 补充必要的说明文档
4. 更新下一步建议（如有新的任务发现）
5. 将完成的任务内容摘要添加到 CHANGELOG.md（可选）

## Git 工作流快速参考

```bash
# 创建功能分支
git checkout -b feature/your-feature-name

# 开发完成后检查
pnpm lint:check && pnpm type-check

# 提交代码（如遇内存问题跳过 husky）
git add .
git commit --no-verify -m "feat(scope): 功能描述"
git push origin feature/your-feature-name
```

**分支命名规范：**
- `feature/xxx` - 新功能
- `fix/xxx` - Bug 修复
- `refactor/xxx` - 代码重构
- `docs/xxx` - 文档更新

## 详细文档

- [ROADMAP_NEXT_STEPS.md](file:///f:/trae/lytjs/docs/development/ROADMAP_NEXT_STEPS.md) - 项目路线图
- [AGENTS.md](file:///f:/trae/lytjs/AGENTS.md) - 项目基础规则
- [CHANGELOG.md](file:///f:/trae/lytjs/CHANGELOG.md) - 变更历史

