---
name: security-scan
description: LytJS 安全扫描指南，提供安全最佳实践和常见安全问题识别
---
# LytJS 安全扫描指南

## 描述

为 LytJS 项目提供安全扫描、安全最佳实践和常见安全问题识别，确保代码库的安全性。

## 何时使用

- 需要检查代码安全性时
- 需要进行安全审计时
- 发现潜在安全问题时

## LytJS 安全要点

### 核心包安全原则

1. **零依赖** - 核心包不引入第三方依赖，避免供应链攻击
2. **输入验证** - 所有外部输入都需要验证
3. **最小权限** - API 只暴露必要的功能

## 常见安全问题检查

### 1. XSS 风险检查

**问题：**
```typescript
// 不安全：直接使用用户输入
function render(content) {
  element.innerHTML = content;
}
```

**检查清单：**
- [ ] 检查所有使用 innerHTML 的地方
- [ ] 检查直接插入 DOM 的内容
- [ ] 检查属性绑定的属性值

**安全做法：**
```typescript
// 安全：使用 textContent
element.textContent = content;

// 或使用安全的属性设置
element.setAttribute('href', encodeURI(url));
```

### 2. Prototype Pollution 检查

**问题：**
```typescript
// 不安全：直接 merge 函数可能污染原型
function merge(target, source) {
  for (const key in source) {
    target[key] = source[key];
  }
}
```

**检查清单：**
- [ ] 检查对象 merge 函数
- [ ] 检查对象属性赋值
- [ ] 检查用户输入作为对象键

**安全做法：**
```typescript
// 安全：检查键名
function merge(target, source) {
  for (const key in source) {
    if (key === '__proto__' || key === 'constructor' || key === 'prototype') {
      continue;
    }
    target[key] = source[key];
  }
}
```

### 3. 不安全的正则表达式（ReDoS）

**问题：**
```typescript
// 不安全：可能导致 ReDoS 攻击
const regex = /^(a+)+$/;
```

**检查清单：**
- [ ] 检查复杂的正则表达式
- [ ] 检查嵌套的重复模式
- [ ] 检查用户输入作为正则

**安全做法：**
```typescript
// 安全：使用简单的正则
const regex = /^a+$/;
```

### 4. 敏感信息泄露

**问题：**
```typescript
// 不安全：将错误信息直接暴露
function handleError(error) {
  console.error('错误:', error);
  throw new Error(`处理失败: ${error}`);
}
```

**检查清单：**
- [ ] 检查错误信息是否包含敏感数据
- [ ] 检查日志输出
- [ ] 检查 API 返回信息

**安全做法：**
```typescript
// 安全：只暴露必要信息
function handleError(error) {
  console.error('错误:', error); // 内部日志可以详细
  throw new Error('处理失败，请稍后重试'); // 用户信息简化
}
```

## 依赖安全检查

### 检查 package.json

```bash
# 检查依赖漏洞（如果有外部依赖）
# 生态包才会引入依赖
cd packages/ui && pnpm audit
```

### 零依赖验证

```bash
# 验证核心包零依赖
cd packages/reactivity
ls node_modules
# 应该只有开发依赖
```

## 安全检查清单

### 代码安全

- [ ] 检查 XSS 风险
- [ ] 检查原型污染风险
- [ ] 检查不安全正则
- [ ] 检查敏感信息泄露

### 输入验证

- [ ] 所有外部输入验证
- [ ] 类型检查正确
- [ ] 边界条件处理

### 依赖安全

- [ ] 核心包零依赖
- [ ] 生态包依赖安全
- [ ] 开发依赖安全

## 安全最佳实践

### 1. 输入验证

```typescript
function safeFunction(input) {
  if (typeof input !== 'string') {
    throw new TypeError('输入必须是字符串');
  }
  if (input.length > 10000) {
    throw new RangeError('输入过长');
  }
  return input;
}
```

### 2. 数据转义

```typescript
function escapeHtml(str) {
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}
```

### 3. 避免 eval 使用

```typescript
// 禁止使用 eval
// 避免使用 new Function
```

## 详细文档

- [ZERO_DEPENDENCY_GUIDE.md](file:///f:/trae/lytjs/docs/development/ZERO_DEPENDENCY_GUIDE.md) - 零依赖指南
- [lytjs-code-review](file:///f:/trae/lytjs/.trae/skills/code-review/SKILL.md) - 代码审查指南

